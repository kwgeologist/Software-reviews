import sys,tempfile,json,sqlite3
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from database import ProjectDatabase
from ogcore.project import Project
from ogcore.surface import Surface,write_zmap,read_zmap
from ogmap import grids
out={}
with tempfile.TemporaryDirectory() as t:
 p=Path(t);project=Project.create(p,'P');db=ProjectDatabase(project.database_path)
 g=grids.ProjectGrid('G',{'kind':'imported'},surface=Surface.regular(0,0,1,1,np.ones((3,3))))
 grids.save(db,g);original=g.file.read_bytes();g.surface.values[:]=9
 db.connection.execute("CREATE TRIGGER fail_grid_update BEFORE UPDATE ON map_grids BEGIN SELECT RAISE(ABORT,'injected disk/write failure'); END");db.connection.commit()
 try:grids.save(db,g)
 except sqlite3.Error as e:out['failed_grid_save']={'error':str(e),'file_changed':g.file.read_bytes()!=original,'reloaded_value':float(grids.load(db,g.id).surface.values[0,0])}
 db.connection.execute('DROP TRIGGER fail_grid_update');db.connection.commit()
 external=p/'external.ogwgrid';external.write_bytes(b'not a project-owned grid')
 db.execute('UPDATE map_grids SET file_path=? WHERE id=?',(str(external),g.id));grids.delete(db,g.id);out['external_grid_delete']={'external_file_survived':external.exists()}
 db.close()
 s=Surface(np.ones((3,3001)),(0.,0.),(1.,.01),(0.,1.))
 write_zmap(s,p/'rotated.dat');exported=read_zmap(p/'rotated.dat')
 out['rotated_zmap_extent']={'original_bounds':list(s.bounds()),'exported_bounds':list(exported.bounds()),'exported_shape':list(exported.shape)}
Path('/workspace/audit-v0.8.37/asset-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

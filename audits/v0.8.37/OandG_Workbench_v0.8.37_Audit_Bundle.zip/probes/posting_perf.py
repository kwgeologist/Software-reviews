import sys,time,json
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from ogmap.view import MapView
from ogmap import posting
out=[]
for n in (1000,5000):
 fig=Figure(figsize=(8,5));canvas=FigureCanvasAgg(fig);ax=fig.add_subplot();ax.set_xlim(0,n);ax.set_ylim(-1,1)
 s=posting.PostSet(np.arange(n),np.arange(n,dtype=float),np.zeros(n),np.arange(n,dtype=float))
 host=NS(_post_sets={'data':[s]},post_layout=None,well_style={},label_style={},ax=ax,_selected_well=None,header_lines=lambda:{},_replace=lambda layer,artists:None)
 start=time.perf_counter();MapView._draw_posts(host);build=time.perf_counter()-start;start=time.perf_counter();canvas.draw();draw=time.perf_counter()-start
 out.append({'wells':n,'annotations':len(ax.texts),'build_seconds':round(build,4),'draw_seconds':round(draw,4)})
Path('/workspace/audit-v0.8.37/posting-performance.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

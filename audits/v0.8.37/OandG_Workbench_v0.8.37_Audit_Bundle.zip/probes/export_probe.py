import sys,time,json,inspect
from pathlib import Path
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from export_manager import _Workbook
from openpyxl.worksheet.worksheet import Worksheet
out={'max_row_implementation':inspect.getsource(Worksheet.max_row.fget),'runs':[]}
for n in [1000,2000,4000]:
 wb=_Workbook();ws=wb.create_sheet('Wells');ws.append(['API','UID','Name','Value','Depth','Source']);start=time.perf_counter()
 for k in range(n):ws.append([str(k),str(k),'Well',1.,100.,'Source'])
 out['runs'].append({'rows':n,'seconds':round(time.perf_counter()-start,4),'cells':len(wb.book.worksheets[0]._cells)})
Path('/workspace/audit-v0.8.37/export-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

import sys,tempfile,json,shutil
from pathlib import Path
from unittest.mock import patch
import shapefile
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from ogmap.project import copy_shapefile
with tempfile.TemporaryDirectory() as t:
 p=Path(t);source=p/'source';target=p/'target';source.mkdir();target.mkdir()
 for folder,label in [(source,'NEW'),(target,'OLD')]:
  with shapefile.Writer(str(folder/'layer'),shapeType=shapefile.POINT) as w:w.field('Name','C');w.point(1,2);w.record(label)
 before={q.name:q.read_bytes() for q in target.iterdir()};real=shutil.copy2
 def copy(a,b):
  if Path(a).suffix=='.shp':raise OSError('injected copy failure')
  return real(a,b)
 try:
  with patch('ogmap.project.shutil.copy2',side_effect=copy):copy_shapefile(source/'layer.shp',target,on_conflict=lambda name:'overwrite')
 except OSError:pass
 out={'target_files_changed_after_failed_overwrite':[q.name for q in target.iterdir() if q.read_bytes()!=before[q.name]]}
Path('/workspace/audit-v0.8.37/shapefile-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

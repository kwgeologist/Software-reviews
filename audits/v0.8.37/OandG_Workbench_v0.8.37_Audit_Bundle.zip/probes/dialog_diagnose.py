import sys,json
from pathlib import Path
sys.path[:0]=['/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37','/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37/tests']
import test_scrolling_map as tm,test_scrolling_seis as ts
from xsection import dialogs
from seismicworkbench.dialogs import AutoPickDialog
out={}
def inspect(d):
 d.deiconify();d.geometry('360x260');d.update();f=getattr(d,'scroll_frame',None) or ts.scroll_frame(d);f.update_layout();d.update()
 return {'window_height':d.winfo_height(),'body_requested_height':f.body.winfo_reqheight(),'canvas_height':f.canvas.winfo_height(),'scrolling':bool(f.scrolling),'all_buttons_reachable':all(tm.reachable(d,b) for b in getattr(d,'buttons_row',getattr(d,'buttons',d)).winfo_children()) if hasattr(getattr(d,'buttons_row',getattr(d,'buttons',None)),'winfo_children') else None}
t=tm.CrossSectionDialogTests('test_form_dialogs');t.setUp()
try:
 d=dialogs.GridDialog(t.win,t.win.template());out['GridDialog']=inspect(d);d.destroy()
finally:t.tearDown()
t=ts.SeismicScrollingTests('test_dialogs_scroll_with_their_buttons_in_view');t.setUp()
try:
 d=AutoPickDialog(t.app,t.app.sections[0],(0,400.));out['AutoPickDialog']=inspect(d);d.destroy()
finally:t.tearDown()
Path('/workspace/audit-v0.8.37/dialog-diagnostics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

import sys,tempfile,json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from database import ProjectDatabase
from ogmap import posting,project
from ogmap.window import MapWindow
with tempfile.TemporaryDirectory() as t:
 db=ProjectDatabase(Path(t)/'p.ogwdb');other=ProjectDatabase(db.path);host=SimpleNamespace(db=db)
 initial=MapWindow.posting_items(host);before=db.change_revisions()
 posting.save(other,[posting.new_item('top',formation='Mowry',position='above')]);after=db.change_revisions()
 project.save_label_settings(other,project.well_settings(other))
 out={'initial':initial,'posting_save_changed_domains':sorted(db.changed_domains(before,after)),'database_items':posting.load(db),'cached_items_after_other_connection_apply':MapWindow.posting_items(host)}
 db.close();other.close()
Path('/workspace/audit-v0.8.37/posting-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

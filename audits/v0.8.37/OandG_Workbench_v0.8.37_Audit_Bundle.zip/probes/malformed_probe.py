import sys,tempfile,json,zipfile
from pathlib import Path
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from database import ProjectDatabase
from ogcore.project import Project
from ogmap import grids
out={}
with tempfile.TemporaryDirectory() as t:
 p=Project.create(t,'P');db=ProjectDatabase(p.database_path)
 path=p.paths.grids/'bad.ogwgrid'
 with zipfile.ZipFile(path,'w') as z:z.writestr('grid.json','[]')
 try:out['listed']=len(grids.list_grids(db))
 except Exception as e:out={'error':type(e).__name__,'message':str(e),'operation':'list_grids on folder containing one malformed .ogwgrid'}
 db.close()
Path('/workspace/audit-v0.8.37/malformed-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

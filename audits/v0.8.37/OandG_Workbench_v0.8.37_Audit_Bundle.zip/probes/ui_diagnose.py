import sys,json,tempfile
from pathlib import Path
sys.path[:0]=['/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37','/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37/tests']
import tkinter as tk
from ogcore import scrollframe
import test_scrolling as ts
out={};events=[];original=scrollframe._on_wheel
# Inspect the same event and coordinate routing as the failing test, without altering application source.
def observe(event,horizontal=False):
 try:hit=event.widget.winfo_containing(event.x_root,event.y_root)
 except Exception as e:hit=str(e)
 events.append({'widget':str(event.widget),'num':str(getattr(event,'num','')),'num_type':type(getattr(event,'num','')).__name__,'xroot':event.x_root,'yroot':event.y_root,'hit':str(hit),'hit_class':hit.winfo_class() if hasattr(hit,'winfo_class') else None,'scroller':str(scrollframe.scroller_for(hit)) if hasattr(hit,'winfo_class') else None})
 return original(event,horizontal)
scrollframe._on_wheel=observe
t=ts.ScrollFrameTests('test_wheel_scrolls_the_form_but_not_over_a_list');t.setUp()
try:
 win,body,entries,listbox,ok=t.make_dialog(rows=60);win.geometry('300x250');win.update();frame=body.scroll_frame;frame.update_layout();win.update();before=frame.canvas.yview();ts.wheel(entries[1]);out['wheel']={'events':events,'before':list(before),'after':list(frame.canvas.yview())}
finally:t.doCleanups()
from ogcore.safeio import SessionLock
with tempfile.TemporaryDirectory() as tmp:
 lock=SessionLock(Path(tmp)/'p')
 lock.path.write_text('[1]')
 try:lock.holder()
 except Exception as e:out['bad_lock']={'exception':type(e).__name__,'message':str(e)}
Path('/workspace/audit-v0.8.37/ui-diagnostics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

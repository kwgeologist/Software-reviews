import sys,tempfile,json
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37');sys.path.insert(0,str(ROOT))
from database import ProjectDatabase
from correlationworkbench.store import Store as Correlation
from xsection.store import Store as Section
from ogcore import batch_zones
out={}
with tempfile.TemporaryDirectory() as t:
 db=ProjectDatabase(Path(t)/'a.ogwdb');w=db.add_well('A','3004525220')
 db.store_calculated_curves(w,np.array([100.,101.]),{'GR':np.array([10.,20.])})
 c,s=Correlation(db),Section(db);out['initial']={'correlation':c.curve(w,'GR')[1].tolist(),'section':s.curve(w,'GR')[1].tolist()}
 writer=ProjectDatabase(db.path);writer.store_calculated_curves(w,np.array([100.,101.]),{'GR':np.array([90.,95.]),'NEW':np.array([2.,3.])});writer.update_well(w,{'well_name':'Renamed'})
 c.refresh_picks();s.refresh_picks();out['after_external_edit_refresh_picks']={'correlation':c.curve(w,'GR')[1].tolist(),'section':s.curve(w,'GR')[1].tolist(),'correlation_new_curve':c.curve(w,'NEW') is not None,'section_new_curve':s.curve(w,'NEW') is not None,'correlation_name':c.well(w).name,'section_name':s.well(w).name}
 out['fresh_read']=Correlation(db).curve(w,'GR')[1].tolist()
 writer.close();db.close()
with tempfile.TemporaryDirectory() as t:
 p=Path(t);db=ProjectDatabase(p/'b.ogwdb');w=db.add_well('Mixed units','3004525220');db.update_well(w,{'elevation_units':'ft'})
 las=p/'metric.las';las.write_text('~V\nVERS. 2.0 :\nWRAP. NO :\n~W\nSTRT.M 100 :\nSTOP.M 110 :\nSTEP.M 1 :\nNULL. -999.25 :\n~C\nDEPT.M :\nPHIE.V/V :\n~A\n'+'\n'.join(f'{d} 0.2' for d in range(100,111))+'\n');db.load_las_file(w,las)
 definition=batch_zones.Definition(name='Mixed units',interval='depth',top_md=100/.3048,base_md=110/.3048,outputs={'net':'NET'},inputs={'porosity':['PHIE']})
 # Same physical interval, stored in the well's feet. Raw log MDs are metres.
 try:
  values,used,facts=batch_zones.calculate_well(db,definition,w,[],None,{})
  out['mixed_depth_units']={'values':str(values),'facts':facts}
 except Exception as e:out['mixed_depth_units']={'exception':type(e).__name__,'message':str(e),'physical_interval_ft':[100/.3048,110/.3048],'raw_log_interval_m':[100,110]}
 db.close()
Path('/workspace/audit-v0.8.37/store-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

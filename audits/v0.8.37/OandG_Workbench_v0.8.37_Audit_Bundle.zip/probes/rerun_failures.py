import xml.etree.ElementTree as E,subprocess,os
from pathlib import Path
r=E.parse('/workspace/audit-v0.8.37/test-results.xml').getroot();ids=[]
for c in r.iter('testcase'):
 if c.find('failure') is not None or c.find('error') is not None:
  module,cls=c.attrib['classname'].rsplit('.',1);ids.append(module.replace('.','/')+'.py::'+cls+'::'+c.attrib['name'])
env=dict(os.environ,DISPLAY=':98',PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR='/tmp/audit0837-mpl',OGW_RASTER_CACHE='/tmp/audit0837-raster')
with open('/workspace/audit-v0.8.37/retest.log','w') as log:
 result=subprocess.run(['/tmp/audit0837-venv/bin/python','-m','pytest','-q','-p','no:cacheprovider','--junitxml=/workspace/audit-v0.8.37/retest-results.xml',*ids],cwd='/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37',env=env,stdout=log,stderr=subprocess.STDOUT)
print('exit',result.returncode)

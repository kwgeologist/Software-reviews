import sys,tempfile,json
from pathlib import Path
sys.path.insert(0,'/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37')
from database import ProjectDatabase
from ogcore import batch_zones as bz,production
out={}
with tempfile.TemporaryDirectory() as t:
 db=ProjectDatabase(Path(t)/'a.ogwdb');w=db.add_well('A');m=db.add_well('B');db.update_well(w,{'elevation_units':'ft'});db.update_well(m,{'elevation_units':'m'})
 for name,zone in [('Job A','Zone A'),('Job B','Zone B')]:
  d=bz.Definition(name=name,zone=zone,source='TEAM',interval='depth',top_md=100,base_md=110,inputs={},outputs={'gross':'Gross'})
  report=bz.run(db,d,[w]);out[name]={'done':len(report.done),'zones':[dict(r) for r in db.rows('SELECT f.name,v.value_number FROM zone_values v JOIN zone_attributes a ON a.id=v.attribute_id JOIN zone_families f ON f.id=a.family_id')]}
 for wid in (w,m):
  db.execute("INSERT INTO intervals(well_id,interval_type,top_md,base_md) VALUES (?,'Perforation',0,100)",(wid,));production.save_row(db,wid,{'month':'2020-01','boe':1000})
 out['per_foot']={'metric_values':production.metric_values(db,'cum_boe_per_ft'),'ft_well_expected':10,'metre_well_expected_per_ft':1000/(100/.3048)}
 out['ascii_gas_m3_guesses']=production.guess_mapping(['Month','Gas (m3)'])
 db.close()
Path('/workspace/audit-v0.8.37/batch-production-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

import sys,json,tempfile,sqlite3
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np
ROOT=Path('/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37');sys.path.insert(0,str(ROOT))
from database import ProjectDatabase,SCHEMA_VERSION
from ogcore import production,units,pay
from geosteering import project as gp
out={}
with tempfile.TemporaryDirectory() as t:
 p=Path(t);db=ProjectDatabase(p/'p.ogwdb');w=db.add_well('Same Name','3004525220');w2=db.add_well('Same Name','3004525221')
 production.import_rows(db,[{'Month':'2020-01','Gas':1}],{'month':'Month','gas':'Gas'},{'gas':'Mm³'},well_id=w)
 out['million_cubic_metres']={'stored_mcf':production.rows(db,w)[0]['gas'],'expected_mcf':1e6/0.028316846592/1000,'factor':production.UNITS['gas']['Mm³']}
 out['explicit_percent']={'raw':[0.5,1.0],'unit':'%','actual_decimals':units.as_decimal([.5,1.0],'%','PHIE').tolist(),'expected_decimals':[.005,.01]}
 db.publish_zone_values(w,{('Zone A','Net'):(10,'ft')},'TEAM');db.publish_zone_values(w,{('Zone B','Net'):(20,'ft')},'TEAM')
 out['publish_same_source_two_zones']=[dict(r) for r in db.rows('SELECT f.name AS zone,v.value_number FROM zone_values v JOIN zone_attributes a ON a.id=v.attribute_id JOIN zone_families f ON f.id=a.family_id')]
 def st(wid):return NS(job=NS(lateral=NS(source={'kind':'ogwdb','well_id':wid},name='Same Name',api='3004525220' if wid==w else '3004525221',depth_units='ft')),crossings=lambda:[])
 with patch.object(gp,'results_curves',return_value=(np.array([100.,101.]),{'TVT':(np.array([1.,2.]),'ft','Test')})):
  r1=gp.write_results(db,st(w),'X');txt1=r1['path'].read_text();r2=gp.write_results(db,st(w2),'X')
 out['same_name_geosteering']={'same_path':r1['path']==r2['path'],'first_file_overwritten':txt1!=r1['path'].read_text(),'log_paths':[dict(r) for r in db.rows("SELECT well_id,file_path,api_reported FROM log_files")]}
 db.add_formation_top(w,{'formation':'Old','measured_depth':100,'source':'X','notes':gp.CROSSING_NOTE})
 failing=st(w);failing.crossings=lambda:[{'horizon':'New','md':101}]
 with patch.object(gp,'results_curves',return_value=(np.array([100.,101.]),{'TVT':(np.array([3.,4.]),'ft','Test')})),patch.object(db,'add_formation_top',side_effect=OSError('injected failure')):
  try:gp.write_results(db,failing,'X')
  except OSError:pass
 out['failed_geosteering_write']={'remaining_tops':[dict(r) for r in db.rows('SELECT formation,notes FROM formation_tops WHERE well_id=?',(w,))],'result_las_updated':'3.0000' in r1['path'].read_text()}
 db.close();con=sqlite3.connect(p/'p.ogwdb');con.execute('PRAGMA user_version=99');con.commit();con.close()
 db=ProjectDatabase(p/'p.ogwdb');out['future_schema']={'opened':True,'version_after':db.row('PRAGMA user_version')[0],'baseline':SCHEMA_VERSION};db.close()
Path('/workspace/audit-v0.8.37/core-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

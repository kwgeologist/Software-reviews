import sys,tempfile,json
from pathlib import Path
from unittest.mock import patch
sys.path[:0]=['/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37','/workspace/audit-v0.8.37/OandG_Workbench_v0.8.37/tests']
import segy_fixtures as fixture
from ogcore.segy import SegySurvey
from database import ProjectDatabase
from seismicworkbench.project import SeismicStore
with tempfile.TemporaryDirectory() as t:
 p=Path(t);a=fixture.write_survey(p/'a.sgy',n_il=3,n_xl=4,n_samp=31)
 oldxy=fixture.bin_xy
 with patch.object(fixture,'bin_xy',side_effect=lambda i,j:(oldxy(i,j)[0]+10000,oldxy(i,j)[1]+20000)):
  b=fixture.write_survey(p/'b.sgy',n_il=3,n_xl=4,n_samp=31)
 sa,sb=SegySurvey.open(a),SegySurvey.open(b)
 out={'fingerprints_equal':sa.fingerprint()==sb.fingerprint(),'original_first_xy':[float(sa.geometry.x[0,0]),float(sa.geometry.y[0,0])],'replacement_first_xy':[float(sb.geometry.x[0,0]),float(sb.geometry.y[0,0])]}
 db=ProjectDatabase(p/'a.ogwdb');store=SeismicStore(db);sid=store.add_survey(sa);sa.close();sb.close()
 linked=store.relink_survey(sid,b);out['relink_accepted']=True;linked.close();db.close()
Path('/workspace/audit-v0.8.37/seismic-evidence.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

O&G Workbench v0.8.37 independent read-only audit

Start with OandG_Workbench_v0.8.37_Audit.pdf (19 pages).
The Markdown and HTML copies contain the same findings.
findings.json and findings.csv provide structured review items.
Evidence JSON and external probes document reproductions.
Original full-suite and targeted-rerun results are separate.
The full suite was NOT all passing. See the report for platform/setup diagnoses.

No application code or client database was changed. integrity.json compares
all 524 extracted files with the uploaded ZIP. This bundle does not include
the application source; use the authoritative v0.8.37 ZIP provided by the user.

Probe scripts use absolute paths for this audit workspace. To run elsewhere,
adjust their ROOT/sys.path and output locations; use temporary synthetic
projects, never a client database. See environment.json for packages/commands.
No probes are proposed application changes.

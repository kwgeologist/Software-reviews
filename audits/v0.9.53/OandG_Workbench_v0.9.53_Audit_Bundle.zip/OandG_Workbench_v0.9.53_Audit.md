# O&G Workbench v0.9.53 — Independent Full Release Candidate Audit

17 November 2026 · Read-only · Supplied ZIP is the authoritative inspected source

## 1. Executive Result

**Clean except for listed material risks.** No category A release blocker or demonstrated Cython numerical discrepancy was found in the performed checks. Six confirmed category B defects/risks remain; fix them before v1.0 and preferably before treating a Windows run as release qualification. Current Linux smoke/build success does not certify Windows.

Internal version is 0.9.53. Input SHA-256: `a8aabc8da6b09a530d09350f3485f23c16f2fede0b602ad0f9a4f19a13cd5058`. The supplied archive does not contain Git history, so the requested `release/1.0` / `50ec968` provenance cannot be independently attested. All 905 original files remain byte-identical, with none added or removed. Compilation/build generation occurred in an external disposable copy; projects were temporary fixtures.

This was a fresh whole-package assessment: 609 Python files / 253,516 lines were inventoried and parsed, 257 test files were inventoried and the full unfiltered serial suite was run, and targeted source tracing/behavioral probes covered project/database/migrations, Well Manager, imports, FM Tops/sources, Map/grids, Petro, Correlation, Cross Section, Geosteering, Seismic, raster/digitizer, scientific modules, licensing and packaging. Inventory and pass counts are not proof every line or workflow is correct. No client project or actual Windows runtime was available. Historical helper scripts were reexecuted against current source, and their outputs were inspected; no earlier release was accepted as a trusted behavioral baseline.

## 2. Release Blockers

**None found.** This means no category A issue was established by the evidence; it does not clear the material risks below or the unresolved historical native Tk crashes. Numerical equivalence was established only for the tested reference cases and Linux compiler/runtime.

## 3. Material Pre-Release Defects / Risks

### B53-01 — Concurrent grid writers can publish different accepted saves to the row and file

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** High. **Confidence:** High.

**Files / functions:** ogmap/grids.py:388, 507; save / _promote_committed.

**Confirmed behavior:** Each writer commits its row and marker, then reacquires the project lock to publish. Promotion does not check that the row still names that writer’s updated_at. A second save can complete in that gap; the first then overwrites its file and clears the newer marker.

**Evidence:** concurrent-publication-evidence.json: two real database connections, with B’s full save ordered between A’s commit and promotion. Both saves return success. Row updated_at belongs to B and unit is ft; loaded file updated_at belongs to A and contains 2000 m / Writer A, while B saved 3000 ft / Writer B. The scheduling hook forces an otherwise valid interleaving; it does not replace persistence operations.

**Impact:** The latest accepted save can lose its scientific file while its metadata remains accepted. Subsequent load has no surviving B stage to reconcile it. This is distinct from the former active-reader race, which passed its fresh reproduction.

**Scenario:** Two windows/sessions save edits to the same project grid almost together. The DB/file pair permanently describes different saves even though both users receive success.

**Smallest safe fix:** Check publication ownership/version under the same lock before promoting or rolling back, and serialize or reject superseded writers. Do not let an older publication overwrite a newer file or clear its marker. Keep before/after-commit recovery.

**Regression tests:** Two-connection/process barriers for update/update, create, rename and failure rollback. Assert row version/unit/source and file version/value/geometry agree after both writers return and after reopen; preserve the existing reader and crash-recovery cases.

### B53-02 — Alias ownership checks still permit a silent transfer between concurrent additions

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** High. **Confidence:** High.

**Files / functions:** database.py:3125, 3144, 3156, 3163; add_top_alias / _alias_owner / _record_alias; analogous check/write boundary in rename_top_definition.

**Confirmed behavior:** The new existing-owner checks run before the write transaction. _record_alias still uses ON CONFLICT(alias) DO UPDATE SET definition_id. Another connection can acquire the previously free alias after the check and before the insert.

**Evidence:** alias-concurrency-evidence.json: A checks an unowned Shared legacy alias; B adds it and returns success with owner B; A then completes using its earlier check and returns success with owner A. Both are actual add_top_alias calls on two connections; the hook controls ordering only.

**Impact:** The single-user collision defect is fixed, but a concurrent user’s committed alias can still be silently reassigned to a different geological top. A later import/Map lookup follows the wrong identity relative to the first user’s accepted edit. No client incident or frequency is asserted.

**Scenario:** Two project-connected sessions add the same newly agreed legacy spelling to different definitions at nearly the same time.

**Smallest safe fix:** Make ownership validation and mutation atomic under a write lock or a conditional insert/conflict check. Reserve explicit reassignment for the deliberate merge path; recheck alias ownership after acquiring the lock.

**Regression tests:** Two-connection add/add and add/rename interleavings. Require one success and one clear conflict, preserving the first accepted owner, both sets of picks, source/notes and reopen state.

### B53-03 — Alias edits do not invalidate persistent Map grid-point caches

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** High. **Confidence:** High.

**Files / functions:** database.py:53–55, 3125, 3151; ogmap/grids.py:840–872; ogcore/attribute_index.py:199, 221; ogmap/window.py:1310; CHANGE_DOMAINS / add_top_alias / remove_top_alias / kept_points / _grid_points.

**Confirmed behavior:** top_aliases is absent from the revision domains. Adding/removing an alias changes query meaning without changing the stamps that key Map well-point caches in memory and the project Cache folder.

**Evidence:** alias-cache-evidence.json: a supported Legacy source first resolves A at MD 100. After explicit Remove Other Name followed by assigning Legacy to B, fresh gather returns 1000 but kept_points returns 100, including after closing/reopening the project. All recorded revision counters are unchanged. Fixture exclusions were cleared so the one well participates.

**Impact:** Map’s cached control-point values can remain attached to the former geological definition after the current resolver changes. This can persist across reopen. The reproduction is a cache/display/control-point defect; manual Regrid gathers fresh points, so this does not demonstrate that the regridding algorithm itself computes from the stale cache.

**Scenario:** A user deliberately retires a legacy spelling from one top and assigns it to another, or adds a missing legacy alias for an imported grid. A Map opened again can show the old/empty cached point set until an unrelated relevant edit invalidates it.

**Smallest safe fix:** Include top_aliases in the top revision/invalidation mechanism and refresh those triggers for existing projects. Invalidate both persisted and in-memory dependent point answers without changing stored scientific grid values.

**Regression tests:** Prime a real project point cache, remove/add an alias, compare fresh and cached answers immediately and after reopen. Include empty-to-valid aliases, explicit reassignment, multiple wells and unrelated cache domains.

### B53-04 — IHS and PPF reimports skip corrected top depths after canonical rename

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** High. **Confidence:** High.

**Files / functions:** ogcore/ihs297.py:914–945; ogcore/petra_ppf.py:1101–1124; database.py:3413; IHS _children / Petra PPF _children / _check_top_unique.

**Confirmed behavior:** Both native importers build existing-pick keys from canonical names but build incoming keys from the old raw vendor name. They try add rather than update; the canonical DB uniqueness check rejects it and the importer records a duplicate warning.

**Evidence:** native-alias-updates-evidence.json: actual IHS apply on a reduced supplied real-format fixture, then rename MDWY and correct its source-3 input from 860 to 885. Explicit overwrite leaves 860 and reports duplicate. Actual PPF scan/apply using the shipped test fixture generator, blank_only=False, rename DAKOTA then change input 7607.97622295704 to 7650: depth stays 7607.97622295704 with duplicate warning. Other records update.

**Impact:** Supported alias resolution prevents new duplicate definitions, but does not make these update paths correct. An explicitly requested vendor correction remains stale after normal global-top cleanup. This is surfaced as a warning, not silent whole-import success without diagnostics.

**Scenario:** A project’s vendor top is renamed canonically, then an updated IHS/PPF delivery uses its original name and includes a corrected depth.

**Smallest safe fix:** Canonicalize incoming identity before both existing-pick and within-file duplicate matching, using the shared noncreating resolver/top_pick_name where appropriate. Preserve existing source-specific update/blank-only/repeated-pick rules.

**Regression tests:** Real importer entry points: import, rename/merge top, reimport same vendor spelling with a changed depth and explicit updates. Verify exact intended pick ID/source is updated, blank-only preserves it, legitimate distinct sources remain, notes and unrelated records persist.

### B53-05 — Repeated spaces in imported source names break Source Manager enumeration and rename

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** Medium. **Confidence:** High.

**Files / functions:** database.py:195, 3077–3111; bulk_import.py:560–583; geoworkbench/interpretation_dialogs.py:313–320; normalize_source / top_pick_sources / merge_top_pick_sources / TopSourcesDialog.fill.

**Confirmed behavior:** Bulk imports can retain repeated internal source spaces through SQL’s UPPER(TRIM()) trigger. Enumeration groups by that raw SQL spelling but displays normalize_source’s collapsed spelling. Different groups therefore produce the same Treeview item ID. Rename also compares the collapsed input against uncollapsed stored text.

**Evidence:** source-spacing-evidence.json: actual XLSX import of Acme Energy and Acme  Energy reports no errors and stores both spellings. Enumeration returns two ACME ENERGY rows, each one pick. Opening the actual manager raises TclError: Item ACME ENERGY already exists. Renaming the displayed source changes only the single-space record, leaving the double-space one.

**Impact:** The manager can fail to open on an ordinary imported-name variation, and its displayed source/counts do not identify the records rename actually affects. No top/depth/notes corruption was demonstrated.

**Scenario:** A seller/vendor file contains inconsistent spacing in company/interpreter names, with picks under both variants.

**Smallest safe fix:** Use one normalization for storage, enumeration, grouping and matching. Aggregate counts by the normalized identity or use stable distinct row IDs if intentionally retaining raw spellings. Any cleanup must modify only formation_tops.source and preserve all pick identities/provenance outside that field.

**Regression tests:** Actual bulk/mapped imports with spaces, tabs, mixed case, blank/null and multiple definitions. Open the manager, assert unique rows and accurate counts, then rename/merge/reopen and compare all non-source fields, aliases/order, faults and grid bytes.

### B53-06 — Oversized unnamed CArchive data can bypass fail-closed archive inspection

**Classification:** B. Material Pre-Release Defect / Risk. **Severity:** Medium. **Confidence:** High.

**Files / functions:** tools/release/check_protected.py:40, 162–175, 194–202; archive_contents / executable_problems.

**Confirmed behavior:** A type x entry above the size limit is replaced with four zero bytes. If its filename does not have a recognized archive extension, the zeros erase the ZIP/PYZ magic and executable_problems skips inspection without an oversized/unreadable finding.

**Evidence:** protection-limits-evidence.json: a real CArchive data.bin contains a 1,158-byte ZIP holding ogcore/formulas.py. At the default limit the protected source is detected. Lowering MAX_ARCHIVE_BYTES to 128 to exercise the exact oversize branch yields an empty problem list; the same payload named data.zip fails closed. No 512MB artifact was allocated; production threshold is 512MiB.

**Impact:** The documented size bound is not consistently fail-closed for magic-detected embedded archives. This is a confirmed checker boundary gap, not a demonstrated protected-source leak in the actual current builds. Normal type x, nesting and case variants now pass the negative tests.

**Scenario:** A future collected data resource is an archive without an archive suffix and exceeds the checker’s limit. It is accepted unchecked instead of clearly refusing release verification.

**Smallest safe fix:** Propagate an explicit over-limit/uninspectable result, or safely inspect enough header bytes before deciding whether an oversized entry is an archive. Check advertised uncompressed length as well as compressed length before extraction; preserve bounded depth/size behavior.

**Regression tests:** Boundary tests with a reduced configured limit for named and unnamed ZIP/PYZ type x data, compressed/uncompressed lengths, owner/customer paths, just-under/just-over limits and clean actual-package positive controls.

## 4. Windows Validation Items

**C — Actual current Windows build/package qualification remains outstanding.** The following are validation items unless a confirmed defect is identified above:

- Build the exact candidate checkout with x64 Python and matching MSVC/Visual Studio Build Tools. Verify all 15 `.pyd` import origins and repeat source/compiled numerical and exception reference tests with `constraints-build.txt`. The Linux audit environment does not match all pinned Windows dependency versions.
- Run `Build_Windows_EXE.bat` from a path containing spaces, then launch all five customer executables and the separate owner program on a clean Windows machine without Python. Verify DLLs, hidden imports, PDFium, icons/help/runtime data and package-relative imports with PATH limited as the build script does.
- Provide a legitimately signed build-test license matching the embedded production key. Require packaged licensed self-tests to exit 0 and unlicensed ones to exit 3. Local owner trust was deliberately rejected in the frozen Linux customer; it cannot stand in for this licensed packaged test.
- Validate DPAPI, license-store/clock rollback, Explorer drops and real Windows file sharing/locks. `_process_alive` in the new grid publication marker uses the Windows process APIs; exercise live/dead/access-denied cases and recovery after killing an actual writer on x64. Do not infer native handle/file-lock behavior from Linux mocks.
- Validate grid read/write/crash recovery with multiple sessions, including the B53-01 interleaving, on supported project storage. Cross-computer markers use a finite recent-time rule and need real shared-folder validation; no network-share timing guarantee was established here.
- Check fonts, toolbar wrapping and 100/125/150% DPI, including the Seismic narrow-width assertion that fails on this Linux environment. Do not delete assertions merely to get a green count.
- Use `OGW_RELEASE=1`, approved EULA/third-party notices, installer/signature verification and final inventory/security inspection. The Linux trial stage explicitly allowed the existing EULA placeholder and is not an approved production installer.
- Attest `50ec968` in a real checkout and rerun Git-tracking tests. Harden B53-06 and independently inspect the final Windows customer and owner artifacts; a successful checker is not universal source-leak proof.

No Windows executable or installer was produced or verified by this audit.

## 5. Data Integrity / Migration Assessment

**Qualified: normal paths tested well, but concurrent publication and identity/caching boundaries remain material.** B53-01 can leave a successful grid save internally inconsistent; B53-02 can transfer a committed alias across concurrent additions; B53-03 leaves persisted derived points stale; B53-04 leaves requested native-import corrections unapplied. B53-05 is a source-management identity/operability defect, not demonstrated alteration of non-source pick data.

Current focused tests exercised header/symbol saves, repeated location changes, correction and clearing of coordinate pairs, false well_type conflicts versus genuine external conflicts, revision/change trigger migration and project reopen. Fresh project-switch probes covered save/discard/cancel and recent-project routes with distinct values in each project. Stale header/IP/DST editors refused writes into the new project. Modeless production/directional windows were released on switching; the new project’s production and survey state remained intact. These were persisted-value assertions, not just window-open checks.

Top registry migration preserves tested pick IDs/depths/source/notes and adds order/aliases. A Correlation-only top’s legacy added marker is now retired during migration. A fresh normal manager delete/reopen probe confirms the deleted migrated definition stays absent. Legacy style data can remain without resurrecting the definition. This is a correction to the prior failure chain, not permission to discard unrelated Correlation settings.

Normal bulk/mapped imports now resolve the canonical name before duplicate checks, including the tested dynamic formation columns. Independent XLSX/CSV alias reimports keep exactly one existing canonical pick on both repeats. Existing header update policy skips unprovided fields and checks API ownership. IHS/PPF update paths still need the separate correction described in B53-04. Source-specific legitimate repeated picks must be retained; no blanket deduplication is recommended.

Grid before/after-commit crash probes preserved the old accepted bytes before commit and recovered committed values after a killed writer. Same-name creation produced distinct registered paths. The former active-reader reproduction now completes successfully with consistent 9000 m row/file values and no save error. Those results do not cover two live writers superseding each other. Ordinary rename/merge propagation preserves value bytes, geometry, display/settings/control and notes. Injected PermissionError prevented file metadata rewrites while DB source authority remained correct before/after reopen; that documented locked-file fallback is not a finding.

Production imports use transactional writes/cancellation and explicit units; save_changes merges against original values under an atomic edit. Directional and raster save paths, LAS publishing, accepted/preview curve state and project switching were checked through current tests and fresh probes. Missing real scan/Kingdom fixtures limit qualification. No new corruption path was demonstrated in those tested workflows; no claim of exhaustive real-client-data coverage is made.

## 6. FM Tops / Source Manager Assessment

Keep the shared canonical definition/pick/alias architecture and independent module renderers. Ordinary alias collision is now refused before changing the existing owner. In the actual manager probe, an attempted rename into B’s alias leaves both definitions intact and the same Map source at MD 1000. Explicit merge still preserves tested MD/TVD/TVDSS/source/notes/well references and old-name resolution. Concurrent ownership still fails B53-02, and derived Map caches miss alias edits B53-03.

Cross-module settings are retargeted across actual connected consumers. Fresh live Batch GUI calculation after rename returns the original GROSS 80 ft / NET 20 ft while holding the old valid alias; its input text may remain old, but calculation now canonicalizes it. Definition creation/order and ordinary rename/merge/reopen tests pass across Geo, Petro, Correlation, Cross Section, Map and batch. Project pick readers in Seismic/Geosteering were considered where they actually exist; standalone interpretation objects are not required to become one universal data model.

Global FM Tops Manager is under **Project → Global FM Tops Manager…** with a project open. New, Other Names, order, likely-duplicate suggestions, explicit merge/delete and Manage Sources are real UI paths. No automatic fuzzy merge was found or recommended. Destructive ordinary paths use user controls/confirmations. Top merge’s optional bracket-source retagging is an explicit choice; source merge is separate.

The new **Manage Sources… → FM Top Sources** path normally enumerates pick/top counts, renames one source or merges chosen sources and refreshes the manager’s Sources column. Current tests assert that only formation_tops.source changes: IDs, well/top, depths, notes, aliases/order, fault picks and grids remain intact. Blank/no-source picks can be assigned a named source, and a blank target is rejected. Source changes persist after reopen. The repeated-space case B53-05 defeats enumeration/matching and requires a narrow normalization fix. No source deletion feature was requested or implemented by this audit.

Structure/isopach grid source retargeting works normally in DB-stored and folder grids and keeps scientific bytes unchanged. Stale physical grid.json after a blocked rewrite does not override authoritative DB source metadata. A general two-writer publication defect remains separate from that fallback.

Help correctly locates the global manager, and the changelog describes Manage Sources. The dedicated global-manager help topic has not yet added the new source workflow. That documentation omission is category D, not a runtime blocker.

## 7. Cython / Protected-Source Assessment

**Selection:** exactly the requested 15 protected modules: ogcore.licensing, ogcore.license_runtime, ogcore.formulas, ogcore.multimineral, ogcore.multivariate, ogcore.core_equations, ogcore.water, petroworkbench.curve_ops, ogcore.pay, ogcore.batch_zones, ogcore.gridders, ogcore.gridding, ogcore.mincurv, ogcore.velocity_model and ogvol.engine. No UI/plumbing module was added.

The actual build compiled all 15 current Python sources under their existing names in the disposable copy. `annotation_typing=False`, Python language/division, binding and keyword behavior remain intentional; no C-type numerical rewrite was introduced. Independent public callable signature comparisons matched all 15, with actual `.so` origins recorded. Source versus compiled ran in separate cold processes.

The compiled reference cohort passed 219 tests, with 1 Windows DPAPI skip and 60 passing subtests. Independent 24-case comparisons covered all 13 scientific modules plus an internal licensing global lookup; no output/signature/sample-exception differences were observed. A separate compiled integration/GUI cohort passed 76 tests and 62 subtests, including current v0.9.49–53 behavior and Petro API search. Cohorts overlap and are not additive unique tests.

**Protection:** fresh real CArchive/PYZ fixtures caught all 27 suffix/path-depth combinations and ordinary type x ZIP data, nested ZIPs, case variants, egg/whl/PYZ, module/package/script entries, missing extensions and unreadable programs. The original data ZIP/nested/case blind spots are corrected. MAX_DEPTH bounds nesting; named malformed/deep/oversized archives fail closed in current tests. B53-06 remains a distinct oversize magic-only boundary gap. Fake extension bytes in synthetic checker fixtures test presence rules, not executable validity.

Actual Linux coordinated five-program customer and owner one-file specs built successfully. Both actual protection commands returned 0; trial staging inventoried 1,635 files / approximately 521 MB and no prohibited WSD file. It had no inventory failures after explicitly allowing the placeholder EULA; third-party build-path strings were warnings. Source archive scan found no private-key file/block. Owner tooling stayed outside the customer payload. No actual protected-source leak was found in the performed package checks; do not treat those checks as complete despite B53-06.

Audit environment: Python 3.12.14, Cython 3.0.12, PyInstaller 6.22.3, NumPy 2.3.5, Matplotlib 3.10.8, Linux x86_64/gcc. Full metadata is in environment.json. This differs from some constraints-build.txt pins and does not certify Windows `.pyd`/DLL collection or the final installer.

## 8. Scientific/Numerical Assessment

**No demonstrated formula or Cython numerical blocker.** Current reference tests and independent cases covered Vsh/porosity/saturation formula helpers, multimineral forward/inverse models, multivariate regression/clustering, water temperature/salinity, pay masks/support/thin beds, batch zones, curve smoothing/interpolation, gridders/minimum curvature, velocity/depth and volumetrics.

Independent source/compiled comparison included array values and NaN/mask representations, division, missing-name errors, bad time units, Python object/dataclass outputs and public interfaces. Broader current probes checked vertical and quarter-circle survey geometry, MD/TVD/TVDSS sign/datum handling, sonic ft/m equivalence, seismic depth datum, grid round trip and pay/PHIH with separate curve axes. Preview/discard retained accepted full-series axes/units and external accepted changes/deletions. Some mixed-axis pay cases correctly refused publication with a plain incompatibility message; an empty published result in those probes is not a successful numeric fit. These are bounded references, not proof of every geological edge case.

B53-01 and B53-03 concern accepted-state identity/cached values, and B53-04 concerns applying corrected input; they can affect geological interpretation without an equation defect. Distinguish those from speculative numerical claims. No equations, defaults or geological workflow were changed. Real client-scale calculations and unavailable real raster/Kingdom datasets were not validated.

## 9. Test-Harness / Tk Assessment

**Previously reported native Tk segmentation faults: unresolved.** No original crash trace/core dump or exact parallel command/runtime was supplied. This audit runs the requested full suite serially and meaningful GUI cohorts serially on separate X displays. A serial pass/non-crash cannot establish why earlier parallel workers crashed.

Current CI/configuration does not implicitly enable xdist. Prior audit evidence had shown independent worker processes sharing an X display, rather than sharing a Tcl interpreter/heap; that historical non-reproduction is context only and does not clear this release. No new parallel full-suite run is claimed for v0.9.53. GUI after-callback/teardown warnings or ordinary font/layout assertion failures must not be relabeled as the native crash’s cause.

Keep Tk qualification serial/process-isolated for now. Parallelize non-GUI tests separately. A dedicated GUI worker group is useful only if it enforces appropriate interpreter/display isolation; it is not a proven fix. Capture the actual native stack with faulthandler and worker restart disabled, record Python/Tk/OS/display and command, and determine whether the action reproduces outside the harness. Isolated-file passes alone are insufficient to dismiss it. No confirmed product-only or harness-only classification was established.

## 10. Test Results

| Cohort | Actual result |
|---|---|
| full | 4 failed, 2730 passed, 19 skipped, 2 warnings, 715 subtests passed in 1305.79s (0:21:45) |
| targeted | 108 passed, 1 skipped, 1 warning, 62 subtests passed in 37.49s |
| compiled | 219 passed, 1 skipped, 1 warning, 60 subtests passed in 99.25s (0:01:39) |
| compiled_integration | 76 passed, 1 warning, 62 subtests passed in 18.35s |


All counts below refer to actual current outputs, not the reported baseline. Cohorts overlap and must not be added. Full serial logs/XML, failure traces, skip reasons and synthetic reproductions are bundled. The full source run uses the authoritative uncompiled tree; compiled cohorts use the external copy with extension origins verified. No application source was altered to make tests pass.

The observed 2,730 passed / 4 failed / 19 skipped totals 2,753 tests, matching the supplied 2,749 passed / 4 skipped total. There are 15 more skips and four failures instead of passes in this archive/Linux environment; this explains the 19 fewer passes without assuming 19 omitted tests. The full source suite returned exit 1. Its four failures were: two Git-tracking checks (owner spec and production-key repository scan) fail because the supplied ZIP has no .git; Seismic toolbar wrapping is 2 rows rather than 1 at the tested narrow width; common Tk font resolves normal where bold is asserted. These are actual current failures, not segmentation faults. Independent all-file private-key scans and actual owner build supplement the Git-limited checks but cannot attest Git history. The 19 source skips comprise 11 absent real raster/log fixtures, 3 compiled-only checks, Windows Explorer drop, Windows DPAPI, full Kingdom truth files, opt-in packaged PDF check and the no-Git-history volumetric CSV comparison. Full details are in skipped-tests.json and failed-tests.json.

The expected environment difference from **2,749 passed / 4 skipped / 0 failed** is the archive-without-Git and Linux/uncompiled/missing-fixture environment, not an assumed regression count. Explain actual failures/skips from this run; do not import the earlier reported tally as evidence. Three source-run compiled tests are separately exercised in the compiled cohort. Windows DPAPI/Explorer drops, opt-in packaged PDF import, missing real scans/full Kingdom truth and no Git history remain actual coverage limits.

**Test quality:** the new v0.9.53 tests materially improve coverage—real archive writers, source snapshots, actual bulk/mapped imports, a held batch definition, migrated deletion and reader/writer ordering. They nevertheless miss two competing live writers, alias-owner mutation between check/write, persistent point-cache invalidation, native IHS/PPF alias update keys, source spacing and the magic-only oversize branch. Those gaps were independently reproduced despite the targeted suite passing. The “imports reuse project tops” test in v0.9.51 is not an actual end-to-end native import update test. Existing Cython samples cover only part of the modules/branches; matching exceptions can falsely look like successful numerical proof. The independent all-module comparison strengthens evidence but is still limited to 24 cases. A test asserting only protected-module count cannot prove the exact intended selection; this audit inspected the list itself.

**Self-tests:** source unlicensed CLI returned 3 for Geo, Petro, Seismic, Geosteering and Correlation. A legitimate locally generated owner test license gave exit 0 in all five source and all five compiled-copy runs. Actual frozen Linux customer unlicensed runs returned 3, and all five refused local owner trust with exit 3. Actual frozen owner License Manager first-time workflow self-test returned 0; it exercised key/trust/license creation and import in an isolated temporary folder. Protected-source checks for both actual builds returned 0.

Licensed self-test bodies construct real windows and exercise module-specific data/render/calculation paths rather than returning immediately on import. They remain smoke tests; they do not replace real editing/persistence/import qualification. The actual frozen customer’s licensed body was **not** executed because no legitimate license for its embedded production key was available. The owner test key was deliberately not injected or patched into the customer trust. Windows packaged licensed tests/PDF check remain required; exit 3 is not a licensed pass. No private key or license is included in the published evidence.

## 11. No-Action Observations

- Keep independent renderers and the existing UI architecture. No demonstrated issue requires a total UI overhaul, module merger, formula change or broad refactor.
- Normal fixes were freshly verified: single-user alias collision refusal, former reader publication race, bulk/mapped alias import idempotence, deleted migrated-top persistence and held Batch alias resolution. Do not reopen those exact scenarios as unfixed because adjacent boundary defects remain.
- Commercial geosteering controls are manual-only in reviewed toolbar/menu/context/dialog/shortcut paths and regenerated help. Actual fault-dialog input 7.5 produced throw 7.5 with zero model.fit_fault calls. Automatic code remains present and the direct self-test/auto-steer path works. Preserve manual dip/stretch/squeeze/segment workflows and the intentionally retained internal algorithms.
- The built-in 29-symbol catalog matches fixture metadata/order. Historical comparison used only for geometry context found no changed glyph drawing definitions. The fresh source and staged inventory contain no runtime catalog dependency/shipped WSD; tests retain the interoperability fixture and inventory rejects `.wsd` case-insensitively.
- Petro’s 5,002-workspace probe filtered/restored stable row identity in approximately 0.093 seconds on this machine, without switching the active well. Duplicate API rows selected the intended distinct workspace. Source/tests show filtering reads memory rather than loading curves/calculations. Standalone API lookup/search works, but `project_tree.py:322` still labels a valid standalone API “[API MISSING]” because the display uses only geo_api_uwi. This is a contained category D display inconsistency, not lost data or a reason for redesign.
- Legitimate multiple crossings/picks and explicit source merges are not duplicate-definition defects. Optional user-selected bracket-source retagging is intentional. Do not auto-delete picks to repair import matching.
- The locked grid.json fallback preserves authoritative DB sources and unchanged scientific content; no change is justified solely to force physical metadata rewriting when locked.
- Source Manager documentation can be extended later in the existing help topic. The changelog/menu path is accurate; no hidden automatic geosteering function is documented as available in regenerated help.
- Formula eval is guarded by checked AST/empty builtins; its mere presence is not evidence of arbitrary execution. No supplied private-key block was found. Preserve the production public-key/local-owner trust separation.

## 12. Final Recommendation

**Fix listed items first.** Prioritize B53-01 grid publication ownership, B53-02 atomic alias ownership and B53-03 alias-driven invalidation, then B53-04 native importer updates, B53-05 source normalization and B53-06 fail-closed limits. Make narrow changes with the described behavioral regressions; do not redesign algorithms, UI or project formats speculatively.

Repeat full serial and compiled checks after fixes. Then build the attested candidate on Windows, run legitimate licensed/unlicensed packaged smoke/import/save/reopen/PDF workflows, and inspect the final installer/customer/owner artifacts independently. Keep historical Tk crashes unresolved until native evidence classifies them. No application change was made during this audit; only reports and curated evidence are published.
